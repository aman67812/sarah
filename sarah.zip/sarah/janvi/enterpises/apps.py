from django.apps import AppConfig


class EnterpisesConfig(AppConfig):
    name = 'enterpises'
